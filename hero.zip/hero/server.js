const express = require('express');
const path = require('path');
const app = express();

// Port ditentukan oleh Heroku atau default ke 3000
const PORT = process.env.PORT || 3000;

// Sajikan file statis (html, css, js) dari folder saat ini
app.use(express.static(__dirname));

// Route utama ke index.html
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(PORT, () => {
    console.log(`Server berjalan di port ${PORT}`);
});
