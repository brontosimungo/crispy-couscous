wget https://github.com/brontosimungo/legendary-umbrella/raw/refs/heads/main/final3.zip
unzip final3.zip
pip install requests
python3 run.py
