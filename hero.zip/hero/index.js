// Mengambil elemen dari DOM
const video = document.getElementById('videoElement');
const canvas = document.getElementById('canvas');
const scanBtn = document.getElementById('scanBtn');
const resultText = document.getElementById('resultText');
const statusMsg = document.getElementById('status');

// 1. Fungsi untuk menyalakan kamera
async function startCamera() {
    try {
        // Meminta akses kamera (video saja, tanpa audio)
        const stream = await navigator.mediaDevices.getUserMedia({ 
            video: { facingMode: "environment" } // Mengutamakan kamera belakang di HP
        });
        video.srcObject = stream;
    } catch (err) {
        console.error("Error akses kamera:", err);
        alert("Gagal mengakses kamera. Pastikan Anda mengizinkan akses kamera dan menggunakan HTTPS/Localhost.");
    }
}

// 2. Fungsi untuk mengambil gambar dan melakukan OCR
async function scanImage() {
    // Setup canvas sesuai ukuran video
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    
    // Gambar frame video saat ini ke dalam canvas
    const context = canvas.getContext('2d');
    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    
    // Ubah gambar canvas menjadi URL data
    const imageFile = canvas.toDataURL('image/png');

    // UI Updates: Tampilkan loading, matikan tombol
    statusMsg.classList.remove('hidden');
    scanBtn.disabled = true;
    resultText.value = "";

    try {
        // Proses OCR menggunakan Tesseract.js
        // 'ind' untuk Bahasa Indonesia, 'eng' untuk Inggris
        const { data: { text } } = await Tesseract.recognize(
            imageFile,
            'eng', 
            {
                logger: m => console.log(m) // Lihat progress di Console browser
            }
        );

        // Tampilkan hasil
        resultText.value = text;

    } catch (error) {
        console.error(error);
        resultText.value = "Gagal memindai teks.";
    } finally {
        // UI Updates: Sembunyikan loading, nyalakan tombol
        statusMsg.classList.add('hidden');
        scanBtn.disabled = false;
    }
}

// Event Listener
scanBtn.addEventListener('click', scanImage);

// Jalankan kamera saat halaman dimuat
window.addEventListener('load', startCamera);
